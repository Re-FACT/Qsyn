//-------------------------------------------
//	FPGA Synthesizable Verilog Netlist
//	Description: Shift register banks used in FPGA
//	Author: Xifan TANG
//	Organization: University of Utah
//	Date: Mon Oct  5 22:01:41 2026
//-------------------------------------------
