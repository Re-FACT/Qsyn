//-------------------------------------------
//	FPGA Synthesizable Verilog Netlist
//	Description: Local Decoders for Multiplexers
//	Author: Xifan TANG
//	Organization: University of Utah
//	Date: Mon Oct  5 22:01:41 2026
//-------------------------------------------
