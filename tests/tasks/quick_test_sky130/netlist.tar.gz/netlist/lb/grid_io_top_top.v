//-------------------------------------------
//	FPGA Synthesizable Verilog Netlist
//	Description: Verilog modules for physical tile: io_top]
//	Author: Xifan TANG
//	Organization: University of Utah
//	Date: Mon Oct  5 22:01:41 2026
//-------------------------------------------
// ----- BEGIN Grid Verilog module: grid_io_top_top -----
//----- Default net type -----
`default_nettype none

// ----- Verilog module for grid_io_top_top -----
module grid_io_top_top(prog_clk,
                       gfpga_pad_EMBEDDED_IO_SOC_IN,
                       gfpga_pad_EMBEDDED_IO_SOC_OUT,
                       gfpga_pad_EMBEDDED_IO_SOC_DIR,
                       bottom_width_0_height_0_subtile_0__pin_outpad_0_,
                       ccff_head,
                       bottom_width_0_height_0_subtile_0__pin_inpad_0_,
                       ccff_tail);
//----- GLOBAL PORTS -----
input [0:0] prog_clk;
//----- GPIN PORTS -----
input [0:0] gfpga_pad_EMBEDDED_IO_SOC_IN;
//----- GPOUT PORTS -----
output [0:0] gfpga_pad_EMBEDDED_IO_SOC_OUT;
//----- GPOUT PORTS -----
output [0:0] gfpga_pad_EMBEDDED_IO_SOC_DIR;
//----- INPUT PORTS -----
input [0:0] bottom_width_0_height_0_subtile_0__pin_outpad_0_;
//----- INPUT PORTS -----
input [0:0] ccff_head;
//----- OUTPUT PORTS -----
output [0:0] bottom_width_0_height_0_subtile_0__pin_inpad_0_;
//----- OUTPUT PORTS -----
output [0:0] ccff_tail;

//----- BEGIN wire-connection ports -----
//----- END wire-connection ports -----


//----- BEGIN Registered ports -----
//----- END Registered ports -----



// ----- BEGIN Local short connections -----
// ----- END Local short connections -----
// ----- BEGIN Local output short connections -----
// ----- END Local output short connections -----

	logical_tile_io_mode_io_ logical_tile_io_mode_io__0 (
		.prog_clk(prog_clk),
		.gfpga_pad_EMBEDDED_IO_SOC_IN(gfpga_pad_EMBEDDED_IO_SOC_IN),
		.gfpga_pad_EMBEDDED_IO_SOC_OUT(gfpga_pad_EMBEDDED_IO_SOC_OUT),
		.gfpga_pad_EMBEDDED_IO_SOC_DIR(gfpga_pad_EMBEDDED_IO_SOC_DIR),
		.io_outpad(bottom_width_0_height_0_subtile_0__pin_outpad_0_),
		.ccff_head(ccff_head),
		.io_inpad(bottom_width_0_height_0_subtile_0__pin_inpad_0_),
		.ccff_tail(ccff_tail));

endmodule
// ----- END Verilog module for grid_io_top_top -----

//----- Default net type -----
`default_nettype wire



// ----- END Grid Verilog module: grid_io_top_top -----

