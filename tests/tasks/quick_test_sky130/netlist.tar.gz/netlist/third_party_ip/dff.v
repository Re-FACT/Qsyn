//-----------------------------------------------------
// Design Name : D-type Flip-flops
// File Name   : ff.v
// Coder       : Xifan TANG
//-----------------------------------------------------

//-----------------------------------------------------
// Function    : A native D-type flip-flop with single output
//-----------------------------------------------------
module DFFQ (
  input CK, // Clock Input
  input D, // Data Input
  output Q // Q output
);
//------------Internal Variables--------
reg q_reg;

//-------------Code Starts Here---------
always @ (posedge CK) begin 
  q_reg <= D;
end

assign Q = q_reg;

endmodule //End Of Module
