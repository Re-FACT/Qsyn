//-----------------------------------------------------
// Design Name : D-type Flip-flops
// File Name   : ff.v
// Coder       : Xifan TANG
//-----------------------------------------------------

//-----------------------------------------------------
// Function    : A native D-type flip-flop with single output
//-----------------------------------------------------
module DFFQ (
  input CK, // Clock Input
  input D, // Data Input
  output Q // Q output
);
//------------Internal Variables--------
reg q_reg;

//-------------Code Starts Here---------
always @ (posedge CK) begin 
  q_reg <= D;
end

assign Q = q_reg;

endmodule //End Of Module

//-----------------------------------------------------
// Function    : D-type flip-flop with 
//               - asynchronous active high reset
//               - asynchronous active high set
//               - scan-chain input
//               - a scan-chain enable 
//-----------------------------------------------------
module SDFFSRQ (
  input SET, // Set input
  input RST, // Reset input
  input CK, // Clock Input
  input SE, // Scan-chain Enable
  input D, // Data Input
  input SI, // Scan-chain input
  output Q // Q output
);
//------------Internal Variables--------
reg q_reg;

//-------------Code Starts Here---------
always @ ( posedge CK or posedge RST or posedge SET)
if (RST) begin
  q_reg <= 1'b0;
end else if (SET) begin
  q_reg <= 1'b1;
end else if (SE) begin
  q_reg <= SI;
end else begin
  q_reg <= D;
end

assign Q = q_reg;

endmodule //End Of Module

