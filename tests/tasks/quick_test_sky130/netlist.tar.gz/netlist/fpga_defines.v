//-------------------------------------------
//	FPGA Synthesizable Verilog Netlist
//	Description: Preprocessing flags to enable/disable features in FPGA Verilog modules
//	Author: Xifan TANG
//	Organization: University of Utah
//	Date: Mon Oct  5 22:01:41 2026
//-------------------------------------------
`define ENABLE_TIMING 1

